import './card-control';
import './lista-control';
import './main-control';
import '@adaws/flip-card';
import '@polymer/iron-ajax/iron-ajax.js';
import '@polymer/iron-image/iron-image'
import '@polymer/paper-item/paper-item'